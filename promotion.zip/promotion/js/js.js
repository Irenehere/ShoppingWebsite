﻿$(document).ready(function(){

	//左菜单
	$(".menu_left>ul>li>a").click(function(){
		$(this).parent("li").siblings().children("ul").slideUp().removeClass("active")
		$(this).next("ul").slideDown().addClass("active")
		$(this).addClass("active").parent("li").siblings().children("a").removeClass("active")
		$(this).prev().removeClass("fa-angle-right").addClass("fa-angle-down")
		$(this).parent("li").siblings().children("i").removeClass("fa-angle-down").addClass("fa-angle-right")
		
		})	



	
	$("#add01").click(function(){
		
		var vala=$("#sj01").val()
		var valb=$("#sj02").val()
		var valc=$("#sj03").val()
		var htmla='<tr><td>'+vala+'</td><td>'+valb+'</td><td>'+valc+'</td></tr>'
		if(vala==''){
				alert("商品不能为空")
				$("#sj01").focus()
					return false;
					}
		
		if(valb==''){
			$("#sj02").focus()
				alert("关键字不能为空")
					return false;
					}
		if(valc==''){
			$("#sj03").focus()
				alert("金额不能为空")
					return false;
					}			
	
	$("#mytg01").append(htmla);
	
	$("#sj01,#sj02,#sj03").val("")
	
	})
	
	
	
	$("#add02").click(function(){
		var valaa=$("#sj011").val()
		var valbb=$("#sj022").val()
		var htmlb='<tr><td>'+valaa+'</td><td>'+valbb+'</td></tr>'
		if(valaa==''){
				alert("商品不能为空")
				$("#sj011").focus()
					return false;
					}
		if(valbb==''){
			$("#sj022").focus()
				alert("金额不能为空")
					return false;
					}			
	
	$("#mytg02").append(htmlb);
	$("#sj011,#sj022").val("")
	})
	
	
		$("#add03").click(function(){
		var valaaa=$("#sj0111").val()
		var valbbb=$("#sj0222").val()
		var htmlc='<tr><td>'+valaaa+'</td><td>'+valbbb+'</td><td>-</td></tr>'
		if(valaaa==''){
				alert("商品不能为空")
				$("#sj0111").focus()
					return false;
					}
		if(valbbb==''){
			$("#sj0222").focus()
				alert("金额不能为空")
					return false;
					}			
	
	$("#mytg03").append(htmlc);
	$("#sj0111,#sj0222").val("")

	})
	
	
	
	
});













